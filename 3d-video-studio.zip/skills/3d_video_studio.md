---
name: 3D Video Studio
description: Flow (Veo/Omni) video generation with a consistent character + auto edit into a finished 3D-style video. Full instructions in skills/3d-video-studio/SKILL.md
version: 1.0.0
---
Read `skills/3d-video-studio/SKILL.md`. Pipeline: voice -> character sheet -> `plan_shots.py` -> Flow video (dry_run first) -> `ingest_clips.py` -> `edit_clips.py` -> master.mp4.
