---
name: 3d-video-studio
description: Turn a script + voiceover into a finished 3D-style video using Google Flow video generation (Veo / Omni) with a consistent character, then auto-edit it (clip fitting, dissolves, Hindi/English karaoke captions, music ducking, SFX, loudness) into master.mp4. Use whenever the user wants a 3D animated video, 3D cartoon / Pixar-style / claymation / low-poly / realistic-CGI explainer or story, an AI video with the SAME character across scenes, image-to-video or chained scenes on Flow, or says "3d video", "video gen with character consistency", "Flow video + edit", even if they never say "skill". Builds on the 2D Video Editing Studio plugin (Cartesia voice, WORDS.tsv sync, fonts, audio library).
---

# 3D Video Studio (Flow video + consistent character + auto edit)

Pipeline: **script -> voice (exact word timing) -> character sheet -> shot plan -> Flow video gen -> ingest -> edit -> master.mp4**

Scripts live in `scripts/` (python3 + ffmpeg + Pillow only). Project folder = same as the 2D studio
(`LINES.tsv`, `VO.wav`, `WORDS.tsv`). Replace `$S` below with this skill's `scripts/` path.

## 0. Laws (read first)
1. **Credits are real money.** Every Flow call goes `dry_run=true` first, show the credit total, wait for the user's OK, then run for real with `max_credits`. Never auto-retry a paid call.
2. **Check Flow is connected** (`flow_get_options` or `deepx_status`). If not, stop and ask the user to connect the DeepX Flow Bridge; never fake clips.
3. **One character sheet per character, created once**, reused in every shot. Never describe the character differently between shots.
4. **Never put script text, subtitles or speech in video prompts** - captions/voice are added in the edit. The planner already appends the no-text/no-speech clause.
5. **Don't skip the intake** in chat mode: ask one question at a time, skip what the user already said.

## 1. Intake (ask only what is missing)
aspect (9:16 reels / 16:9) - language (hi/en) - 3D look (`pixar` `clay` `lowpoly` `toon` `realistic` `isometric` or free text) - character(s) (name + visual description, or an uploaded reference image) - model/budget (default **Omni 1.1 Flash 720p**; Veo Fast/Lite for more realism; Veo Quality cannot use ingredients) - script (or topic -> write it) - voice (Cartesia key / own VO file).

## 2. Voice + exact timing (reuse the 2D studio)
```bash
python studio.py new ~/videos/my3d && cd ~/videos/my3d     # creates the project
# write LINES.tsv (copy templates/LINES.tsv for the extra columns), then:
python studio.py voice                                      # -> VO.wav + WORDS.tsv (exact word times)
```
Own recording instead: put `VO.wav` in the folder and run the studio's `align` step to get `WORDS.tsv`.
**Fill the extra LINES.tsv columns yourself** (Claude writes them, in English):
`action` (what visibly happens: motion, emotion, props - the most important column), `scene` (same value = same place -> chained, continuous shots), `camera` (optional), `chars` (optional), `setting` (optional).

## 3. Plan
```bash
python $S/plan_shots.py --project . --aspect 9:16 --model omni --resolution 720p --style pixar \
   --character "Mochi=a small round orange tabby cat with big green eyes, white chest patch, blue scarf" \
   --max-credits 400
```
Prints shots / method / credits and writes `SHOTS3D.json` + `flow_queue.json`.
- Shots are <= the model's clip length (Omni 10 s, Veo 8 s); one shot can cover 1-3 lines; a long line is split into continued shots.
- `method`: `ingredients` (character reference images attached) for the first shot of every scene, `chain` (last frame -> next start frame) for later shots of the same scene, `text` only if no character.
- `--consistency ingredients|chain|text` forces a method. Several characters: repeat `--character` (max 3 per shot).
- Estimated credits use the Omni table from the tool description; Veo prices are unknown to the script -> the dry_run tells you.

## 4. Generate on Flow (follow `flow_queue.json` step by step)
**Step "characters"** - for each call: `flow_generate_character` (dry_run first). Then `flow_list_characters` to confirm the `@handle` exists. If the user gave a reference image use `flow_upload_character` (+ rename) instead. Show the sheet to the user and get approval **before** any video (a bad sheet ruins every shot).

**wave_0** - ONE `flow_generate_video` call with every shot in `items` (parallel; do not loop one by one). Args: `model`, `aspect_ratio`, `resolution`, `items[{prompt, duration, references}]`, `max_credits`. Run `dry_run=true` first. The call waits ~1-5 min; keep polling with `flow_video_status(media_ids)`; finished mp4 land in `~/flow-media`.

**wave_1..n (chained shots)** - for each: `flow_chain_scene(media_id=<previous shot's media id>, next_prompt, model, aspect_ratio, duration, no_references=true)`. Replace `{{media_id:shot_xx}}` with the real id. Independent chains in a wave can be sent together.
(Alternative for Veo clips: `flow_extend_video`; for Omni: `flow_extract_frame` upload then `flow_generate_video` with `start_frame`.)

Hard limits from the bridge: Veo = 8 s @720p only; Omni = 4/6/8/10 s, 360p or 720p; aspect 16:9 or 9:16; **ingredients and start/end frames cannot be mixed in one call**; Veo Quality has no ingredients.

**Bad shot?** Re-generate only that shot (new `items` with just it, tweak the action, keep the same references). For a broken chained shot regenerate the shot **and** everything chained after it.

## 5. Ingest
```bash
python $S/ingest_clips.py --project . --clip shot_01=~/flow-media/<file>.mp4 --media-id shot_01=<flow media id> ...
python $S/ingest_clips.py --project . --status
```
Validates each file, copies to `clips/`, records media ids (needed for chaining and re-runs).

## 6. Edit -> master.mp4
```bash
python $S/edit_clips.py --project . --music ~/studio/audio/music/documentary_and_history/history_serious.mp3 \
   --sfx-dir ~/studio/audio/sfx/transition
```
What it does: fits every clip to its voice span (speed +-15 %, else trim / freeze last frame) - dissolve between scenes, hard cut inside chained shots - karaoke captions from `WORDS.tsv` - music bed ducked under the voice - whoosh at dissolves - loudnorm -14 LUFS - output length == voice length, audio frame 0 == video frame 0. Writes `edit_report.json`.

Useful flags: `--res 720|540` (faster preview) - `--lowmem` (phone/Termux) - `--no-captions` - `--caption-mode karaoke|pop|box` - `--punch` (6 % push-in) - `--ambient-db -28` (keep Flow's own sound quietly) - `--transition smoothleft|wipeleft|circleopen|none` - `--allow-missing` (grey placeholders to preview timing before all clips exist) - `--lang hi|en` - `--font-file`.
Hindi/English font is picked from the 2D studio `fonts/` folder (Baloo2 / Anton); set `STUDIO_ROOT` if the plugin lives elsewhere.

## 7. Check before delivering
`edit_report.json` has `warnings` (orientation mismatch, estimated captions, missing fonts). Extract 2-3 frames (`ffmpeg -ss 5 -i master.mp4 -frames:v 1 f.png`) and look at caption position/legibility and character consistency. Ship `master.mp4`; offer fixes (re-gen one shot, change music, caption style).

## Prompt craft for 3D shots (when you write `action`)
- One clear action per shot, visible motion, 1-2 beats max for 8 s. Emotion in the face/body, not in text.
- Camera words that work: slow push-in, orbit, tracking follow, crane up, pull-back reveal.
- Keep environment nouns concrete (materials, light, time of day); the style clause is added for you.
- Never change character wording between shots; refer to them by name/@handle only.

## Troubleshooting
- `ffmpeg not found` -> install ffmpeg (Termux: `pkg install ffmpeg`).
- Captions show boxes -> pass `--font-file` for the script's language.
- Drift/early captions -> `WORDS.tsv` is estimated; regenerate voice/align.
- Character drifts in chained shots -> after 3-4 chained shots start a new scene (new `scene` value) so ingredients re-anchor.
- Self-check of this skill's code (no Flow, no credits): `python $S/selftest.py`.
