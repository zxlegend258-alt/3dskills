# -*- coding: utf-8 -*-
"""common.py - shared helpers for the 3D Video Studio scripts (stdlib only)."""
import csv, json, os, re, subprocess, sys

def die(msg, code=1):
    print("ERROR: " + str(msg), file=sys.stderr)
    sys.exit(code)

def warn(msg):
    print("WARN: " + str(msg), file=sys.stderr)

def run(cmd, cwd=None):
    r = subprocess.run(cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if r.returncode != 0:
        tail = "\n".join((r.stderr or "").strip().splitlines()[-25:])
        raise RuntimeError("command failed: %s\n%s" % (" ".join(map(str, cmd))[:300], tail))
    return r

def have(binary):
    from shutil import which
    return which(binary) is not None

def probe(path):
    """-> dict(duration,width,height,fps,has_video,has_audio)"""
    r = run(["ffprobe", "-v", "error", "-show_entries",
             "format=duration:stream=codec_type,width,height,r_frame_rate",
             "-of", "json", path])
    j = json.loads(r.stdout or "{}")
    out = dict(duration=0.0, width=0, height=0, fps=0.0, has_video=False, has_audio=False)
    try:
        out["duration"] = float(j.get("format", {}).get("duration") or 0)
    except ValueError:
        pass
    for s in j.get("streams", []):
        if s.get("codec_type") == "video" and not out["has_video"]:
            out["has_video"] = True
            out["width"], out["height"] = int(s.get("width") or 0), int(s.get("height") or 0)
            try:
                a, b = (s.get("r_frame_rate") or "0/1").split("/")
                out["fps"] = float(a) / float(b or 1)
            except Exception:
                pass
        elif s.get("codec_type") == "audio":
            out["has_audio"] = True
    return out

def read_tsv(path):
    """Tolerant TSV reader (BOM, CRLF, blank lines). Returns list[dict]."""
    with open(path, encoding="utf-8-sig", newline="") as f:
        text = f.read().replace("\r\n", "\n").replace("\r", "\n")
    rows = []
    reader = csv.DictReader(text.split("\n"), delimiter="\t")
    for r in reader:
        r = {(k or "").strip(): (v or "").strip() for k, v in r.items() if k is not None}
        if any(r.values()):
            rows.append(r)
    return rows

def read_json(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)

def write_json(path, obj):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)

def idkey(x):
    """'01' and '1' are the same line id."""
    s = str(x).strip()
    return s.lstrip("0") or "0"

def slug(s):
    s = re.sub(r"[^A-Za-z0-9]+", "_", str(s)).strip("_").lower()
    return s or "char"

def studio_root():
    """Find the 2D studio plugin root (the folder that has fonts/hindi)."""
    env = os.environ.get("STUDIO_ROOT")
    if env and os.path.isdir(env):
        return env
    here = os.path.dirname(os.path.abspath(__file__))
    cur = here
    for _ in range(6):
        if os.path.isdir(os.path.join(cur, "fonts", "hindi")):
            return cur
        cur = os.path.dirname(cur)
    return None

def first_existing(*paths):
    for p in paths:
        if p and os.path.exists(p):
            return p
    return None
