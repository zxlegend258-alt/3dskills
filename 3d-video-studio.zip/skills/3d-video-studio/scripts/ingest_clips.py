#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ingest_clips.py - register downloaded Flow mp4 files into the project.

  ingest_clips.py --project P --clip shot_01=/path/a.mp4 --clip shot_02=/path/b.mp4 \
                  [--media-id shot_01=<flow media id>]
  ingest_clips.py --project P --map map.json     # {"shot_01": {"path": "...", "media_id": "..."}}
  ingest_clips.py --project P --status           # what is done / missing
"""
import argparse, os, shutil, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *


def status(plan, P):
    miss = []
    for s in plan["shots"]:
        ok = s.get("clip") and os.path.exists(os.path.join(P, s["clip"]))
        print("%-8s %-8s %-11s %s" % (s["id"], "OK" if ok else "MISSING", s["method"], s.get("media_id") or "-"))
        if not ok:
            miss.append(s["id"])
    print("%d/%d clips ready" % (len(plan["shots"]) - len(miss), len(plan["shots"])))
    return miss


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--project", required=True)
    ap.add_argument("--clip", action="append", default=[])
    ap.add_argument("--media-id", action="append", default=[])
    ap.add_argument("--map")
    ap.add_argument("--status", action="store_true")
    a = ap.parse_args()
    P = a.project
    pp = os.path.join(P, "SHOTS3D.json")
    if not os.path.exists(pp):
        die("run plan_shots.py first (SHOTS3D.json missing)")
    plan = read_json(pp)
    by = {s["id"]: s for s in plan["shots"]}
    todo = {}
    if a.map:
        for k, v in read_json(a.map).items():
            todo[k] = dict(path=v["path"] if isinstance(v, dict) else v, media_id=(v.get("media_id") if isinstance(v, dict) else None))
    for c in a.clip:
        if "=" not in c:
            die("--clip needs shot_id=path")
        k, v = c.split("=", 1)
        todo.setdefault(k.strip(), {})["path"] = os.path.expanduser(v.strip())
    for m in a.media_id:
        k, v = m.split("=", 1)
        todo.setdefault(k.strip(), {})["media_id"] = v.strip()
    os.makedirs(os.path.join(P, "clips"), exist_ok=True)
    bad = 0
    for k, v in todo.items():
        if k not in by:
            warn("unknown shot id " + k); bad += 1; continue
        s = by[k]
        if v.get("media_id"):
            s["media_id"] = v["media_id"]
        src = v.get("path")
        if not src:
            continue
        if not os.path.exists(src):
            warn("file not found: " + src); bad += 1; continue
        try:
            info = probe(src)
        except Exception as e:
            warn("%s: unreadable (%s)" % (k, str(e).splitlines()[0])); bad += 1; continue
        if not info["has_video"] or info["duration"] < 1.0:
            warn("%s: not a valid video (dur %.2fs)" % (k, info["duration"])); bad += 1; continue
        portrait = info["height"] > info["width"]
        if portrait != (plan["meta"]["aspect"] == "9:16"):
            warn("%s: clip is %dx%d but project is %s - it will be center-cropped" % (k, info["width"], info["height"], plan["meta"]["aspect"]))
        dst = os.path.join(P, "clips", k + ".mp4")
        if os.path.abspath(src) != os.path.abspath(dst):
            shutil.copyfile(src, dst)
        s["clip"] = "clips/%s.mp4" % k
        s["status"] = "ready"
        s["clip_info"] = dict(duration=round(info["duration"], 3), width=info["width"], height=info["height"], has_audio=info["has_audio"])
        print("ingested %s  %dx%d  %.2fs  audio=%s" % (k, info["width"], info["height"], info["duration"], info["has_audio"]))
    write_json(pp, plan)
    miss = status(plan, P) if (a.status or todo) else []
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
