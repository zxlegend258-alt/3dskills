#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""plan_shots.py - LINES.tsv + WORDS.tsv (+VO.wav)  ->  SHOTS3D.json + flow_queue.json

Splits the voiceover into Flow-sized video shots (<= model max clip length), decides how each
shot keeps the character consistent (ingredients / chain / text), writes one master prompt per
shot, estimates credits, and emits an ordered queue of Flow MCP tool calls.

LINES.tsv columns:  id  text  [gap]  [scene]  [action]  [camera]  [chars]  [setting]
  action  = English description of what visibly happens (YOU/Claude must write it)
  scene   = same value on consecutive lines => same location => shots are chained
  chars   = comma separated character names (default: all defined characters)
"""
import argparse, math, os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *

STYLES = {
    "pixar": "stylized 3D animated feature-film look, soft rounded shapes, expressive faces, subtle subsurface skin shading, warm cinematic global illumination, shallow depth of field, rich saturated colors",
    "clay": "handcrafted 3D claymation look, soft clay texture with fingerprints, slightly imperfect shapes, tilt-shift miniature lighting, stop-motion feel",
    "lowpoly": "clean low-poly 3D render, flat-shaded facets, pastel gradient lighting, minimal geometric environment, soft ambient occlusion",
    "toon": "cel-shaded 3D cartoon look, bold clean outlines, bright colors with simple soft shadows, playful exaggerated motion",
    "realistic": "photorealistic 3D CGI render, physically based materials, cinematic volumetric lighting, ultra detailed, 35mm film look",
    "isometric": "isometric 3D diorama render, tiny detailed world, soft studio lighting, tilt-shift depth of field, clean pastel palette",
}
CAMERAS = [
    "slow push-in", "gentle orbit to the left", "slow pull-back reveal",
    "low-angle tracking follow", "slow pan to the right", "static medium shot with subtle handheld drift",
    "slow crane up", "over-the-shoulder drift",
]
MODELS = {
    "omni": "Omni 1.1 Flash", "veo-lite": "Veo 3.1 - Lite",
    "veo-fast": "Veo 3.1 - Fast", "veo-quality": "Veo 3.1 - Quality",
}
OMNI_DURS = [4, 6, 8, 10]
# credits per clip, from the flow_generate_video tool description (confirm with a dry_run!)
OMNI_CREDITS = {"360p": {4: 4, 6: 5, 8: 6, 10: 7}, "720p": {4: 7, 6: 10, 8: 12, 10: 15}}
NEG = ("No dialogue, no speech, no singing, no background music, no on-screen text, no subtitles, "
       "no logos, no watermark; subtle natural ambient sound only.")
WPS = 2.6  # fallback speaking speed (words / sec) when no word timings exist


def credits_for(model, res, dur, veo_credit):
    if "Omni" in model:
        return OMNI_CREDITS.get(res, {}).get(dur)
    return veo_credit


def load_timeline(P, lines, args):
    words = {}
    wp = args.words or os.path.join(P, "WORDS.tsv")
    if os.path.exists(wp):
        for r in read_tsv(wp):
            try:
                words.setdefault(idkey(r["line"]), []).append((float(r["start"]), float(r["end"])))
            except (KeyError, ValueError):
                continue
    table, cursor, exact = [], 0.0, 0
    for ln in lines:
        k = idkey(ln["id"])
        gap = float(ln.get("gap") or 0.35)
        if k in words and words[k]:
            s = max(0.0, min(a for a, _ in words[k]))
            e = max(b for _, b in words[k])
            timing = "words"; exact += 1
        else:
            n = max(1, len(ln["text"].split()))
            s = cursor
            e = s + n / WPS
            timing = "estimate"
        table.append(dict(id=ln["id"], text=ln["text"], t0=round(s, 3), t1=round(e, 3), timing=timing))
        cursor = e + gap
    vo = args.vo or first_existing(*[os.path.join(P, n) for n in ("VO.wav", "vo.wav", "voice.wav", "VO.mp3", "vo.mp3")])
    total = probe(vo)["duration"] if vo else 0.0
    if total <= 0:
        total = table[-1]["t1"] + 0.5
    if exact and exact < len(lines):
        warn("only %d/%d lines have word timings; the rest are estimated" % (exact, len(lines)))
    if not exact:
        warn("no WORDS.tsv timings found -> shot timing is ESTIMATED. Run the studio's voice/align step first for exact sync.")
    return table, total


def make_shots(table, lines, total, args, max_clip):
    pad = args.xf  # extra seconds a clip needs for the dissolve tail
    cap = max_clip - pad
    # shot start boundaries sit just before the first word of a line
    starts = []
    for i, t in enumerate(table):
        prev_end = table[i - 1]["t1"] if i else 0.0
        starts.append(0.0 if i == 0 else max(prev_end, t["t0"] - min(0.10, (t["t0"] - prev_end) / 2.0)))
    bounds = starts + [total]
    groups, cur = [], None
    for i, ln in enumerate(lines):
        scene = ln.get("scene") or ""
        span_if_added = bounds[i + 1] - (bounds[cur["idx"][0]] if cur else bounds[i])
        same_scene = cur and (scene == cur["scene"]) and (scene != "" or args.merge_unscened)
        if cur and same_scene and span_if_added <= cap and len(cur["idx"]) < args.max_lines:
            cur["idx"].append(i)
        else:
            cur = dict(idx=[i], scene=scene)
            groups.append(cur)
    shots = []
    for g in groups:
        a, b = bounds[g["idx"][0]], bounds[g["idx"][-1] + 1]
        span = b - a
        parts = max(1, math.ceil(span / cap - 1e-9))
        for p in range(parts):
            shots.append(dict(group=g, t0=a + span * p / parts, t1=a + span * (p + 1) / parts, part=p, parts=parts))
    return shots


def pick_duration(model, span, pad):
    need = span + pad
    if "Omni" in model:
        for d in OMNI_DURS:
            if d >= need - 1e-9:
                return d
        return OMNI_DURS[-1]
    return 8


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--project", required=True)
    ap.add_argument("--lines"); ap.add_argument("--words"); ap.add_argument("--vo")
    ap.add_argument("--aspect", default="9:16", choices=["9:16", "16:9"])
    ap.add_argument("--model", default="omni", help="omni | veo-lite | veo-fast | veo-quality (or exact Flow name)")
    ap.add_argument("--resolution", default="720p", choices=["360p", "720p"])
    ap.add_argument("--style", default="pixar", help="|".join(STYLES) + " or any free text")
    ap.add_argument("--character", action="append", default=[], help='"Name=visual description" (repeatable)')
    ap.add_argument("--consistency", default="auto", choices=["auto", "ingredients", "chain", "text"])
    ap.add_argument("--max-credits", type=int, default=0, help="hard cap for the whole run (0 = no cap, only warn)")
    ap.add_argument("--veo-credit", type=int, default=None, help="credits per Veo clip if you know it (else unknown)")
    ap.add_argument("--xf", type=float, default=0.30, help="dissolve length between scenes (sec)")
    ap.add_argument("--max-lines", type=int, default=3, help="max script lines merged into one shot")
    ap.add_argument("--merge-unscened", action="store_true", help="merge consecutive lines that have no scene value")
    ap.add_argument("--extra", default="", help="extra text appended to every prompt (e.g. world rules)")
    a = ap.parse_args()

    P = a.project
    lp = a.lines or os.path.join(P, "LINES.tsv")
    if not os.path.exists(lp):
        die("LINES.tsv not found in " + P)
    lines = read_tsv(lp)
    if not lines or "text" not in lines[0]:
        die("LINES.tsv needs columns: id, text (tab separated)")
    for i, ln in enumerate(lines):
        ln.setdefault("id", "%02d" % (i + 1))
        if not ln["id"]:
            ln["id"] = "%02d" % (i + 1)

    model = MODELS.get(a.model.lower(), a.model)
    if model not in MODELS.values():
        die("unknown model %r. Use: %s" % (a.model, ", ".join(MODELS)))
    is_omni = "Omni" in model
    max_clip = 10 if is_omni else 8
    style = STYLES.get(a.style, a.style)

    # characters -----------------------------------------------------------------
    chars = {}
    cj = os.path.join(P, "characters.json")
    if os.path.exists(cj):
        chars.update(read_json(cj))
    for c in a.character:
        if "=" not in c:
            die('--character must look like "Name=description"')
        n, d = c.split("=", 1)
        chars[n.strip()] = {"prompt": d.strip(), "handle": "@" + slug(n)}
    for n, c in chars.items():
        c.setdefault("handle", "@" + slug(n))
    if not chars:
        warn("no characters defined -> shots use text-only prompts (no consistency anchor!)")

    table, total = load_timeline(P, lines, a)
    raw = make_shots(table, lines, total, a, max_clip)
    id2i = {ln["id"]: i for i, ln in enumerate(lines)}

    shots, missing_action, quality_warned = [], [], False
    for n, r in enumerate(raw):
        g = r["group"]
        idxs = g["idx"]
        first = lines[idxs[0]]
        sid = "shot_%02d" % (n + 1)
        span = r["t1"] - r["t0"]
        scene = g["scene"]
        prev = shots[-1] if shots else None
        continuing = bool(prev and ((r["part"] > 0) or (scene and scene == prev["scene"])))
        # who is on screen
        names = []
        for ln in (lines[i] for i in idxs):
            for nm in [x.strip() for x in (ln.get("chars") or "").split(",") if x.strip()]:
                if nm in chars and nm not in names:
                    names.append(nm)
        if not names:
            names = list(chars)[:3]
        names = names[:3]
        # method ---------------------------------------------------------------
        if a.consistency == "text" or not names:
            method = "text"
        elif a.consistency == "ingredients":
            method = "ingredients"
        elif a.consistency == "chain":
            method = "chain" if prev else "ingredients"
        else:
            method = "chain" if continuing else "ingredients"
        if method == "chain" and not prev:
            method = "ingredients" if names else "text"
        if method == "ingredients" and model == "Veo 3.1 - Quality":
            if not quality_warned:
                warn("Veo Quality does not accept ingredients -> first shot of each scene uses text only. Use omni/veo-fast/veo-lite for better consistency.")
                quality_warned = True
            method = "text"
        # prompt ---------------------------------------------------------------
        action = " ".join((lines[i].get("action") or "").strip() for i in idxs).strip()
        if not action:
            missing_action.extend(lines[i]["id"] for i in idxs)
            action = "the character performs a clear, readable action that matches the moment, with expressive face and body language"
        cam = first.get("camera") or CAMERAS[n % len(CAMERAS)]
        setting = (first.get("setting") or "").strip()
        who = ", ".join("%s (%s)" % (nm, chars[nm]["handle"]) for nm in names)
        cdesc = " ".join("%s: %s." % (nm, chars[nm]["prompt"]) for nm in names)
        lock = ("Character consistency: %s keep the exact same face, body proportions, colors and outfit as the reference, in every frame." % who) if names else ""
        if method == "chain":
            head = "Continue seamlessly from the previous frame - same location, same lighting, same character design."
            prompt = " ".join(x for x in [head, action + ".", "Camera: %s." % cam, setting and (setting + "."), lock, NEG, a.extra] if x)
        else:
            prompt = " ".join(x for x in [style[0].upper() + style[1:] + ".", ("Subject: " + cdesc) if names else "", ("Setting: " + setting + ".") if setting else "",
                                           action + ".", "Camera: %s." % cam, lock, NEG, a.extra] if x)
        dur = pick_duration(model, span, a.xf)
        shots.append(dict(
            id=sid, lines=[lines[i]["id"] for i in idxs], scene=scene, part=r["part"], parts=r["parts"],
            t0=round(r["t0"] if n else 0.0, 3), t1=round(r["t1"], 3), span=round(span, 3),
            flow_duration=dur, method=method, depends_on=(prev["id"] if method == "chain" else None),
            model=model, resolution=a.resolution if is_omni else "720p", aspect_ratio=a.aspect,
            references=[chars[nm]["handle"] for nm in names] if method == "ingredients" else [],
            characters=names, camera=cam, prompt=prompt,
            credits=credits_for(model, a.resolution, dur, a.veo_credit),
            status="planned", clip=None, media_id=None,
        ))
    if missing_action:
        warn("lines without an `action` column value: %s  -> write English actions in LINES.tsv for much better video!" % ",".join(sorted(set(missing_action))))

    known = [s["credits"] for s in shots if s["credits"] is not None]
    total_credits = sum(known)
    unknown = len(shots) - len(known)

    plan = dict(
        version=1,
        meta=dict(aspect=a.aspect, model=model, resolution=a.resolution if is_omni else "720p", style=a.style,
                  total_duration=round(total, 3), xf=a.xf, consistency=a.consistency,
                  credits_known=total_credits, shots_with_unknown_credits=unknown),
        characters=chars,
        line_table=table,
        shots=shots,
    )
    # ---- queue -----------------------------------------------------------------
    steps = []
    if chars:
        steps.append(dict(step="characters", note="create each character ONCE; then flow_list_characters to confirm the @handles",
                          calls=[dict(tool="flow_generate_character", args=dict(
                              character_name=n, native_studio=True, aspect_ratio="3:4",
                              prompt="%s. Full-body character reference sheet look, three-quarter view, neutral standing pose, centered, plain light grey studio background, even soft lighting, %s, clean consistent design, no text." % (c["prompt"], style)))
                              for n, c in chars.items()]))
    depth = {}
    for s in shots:
        depth[s["id"]] = 0 if not s["depends_on"] else depth[s["depends_on"]] + 1
    for d in range(max(depth.values()) + 1):
        wave = [s for s in shots if depth[s["id"]] == d]
        if d == 0:
            items = []
            for s in wave:
                it = dict(prompt=s["prompt"], duration=s["flow_duration"])
                if s["references"]:
                    it["references"] = s["references"]
                items.append(it)
            args = dict(model=model, aspect_ratio=a.aspect, items=items)
            if is_omni:
                args["resolution"] = a.resolution
            steps.append(dict(step="wave_0", note="ONE call, all shots in items (parallel). Results come back in the same order as `shots`.",
                              shots=[s["id"] for s in wave], calls=[dict(tool="flow_generate_video", args=args)]))
        else:
            calls = []
            for s in wave:
                args = dict(media_id="{{media_id:%s}}" % s["depends_on"], next_prompt=s["prompt"], model=model,
                            aspect_ratio=a.aspect, duration=s["flow_duration"], no_references=True)
                calls.append(dict(shot=s["id"], tool="flow_chain_scene", args=args))
            steps.append(dict(step="wave_%d" % d, note="needs the media ids of the previous wave: replace {{media_id:shot_xx}}", shots=[s["id"] for s in wave], calls=calls))
    cap = a.max_credits or None
    queue = dict(
        rules=["ALWAYS run each call with dry_run=true first (no credits), show the user the credit total, then run for real.",
               "Pass max_credits on every real call. Never retry a failed paid call without telling the user.",
               "After each wave: flow_video_status(media_ids) -> files land in ~/flow-media -> ingest_clips.py"],
        credit_estimate=dict(known=total_credits, shots_with_unknown_credits=unknown, max_credits=cap),
        steps=steps)
    write_json(os.path.join(P, "SHOTS3D.json"), plan)
    write_json(os.path.join(P, "flow_queue.json"), queue)

    # ---- summary ---------------------------------------------------------------
    print("Plan: %d lines -> %d shots | %s %s %s | VO %.1fs" % (len(lines), len(shots), model, plan["meta"]["resolution"], a.aspect, total))
    print("%-8s %-9s %5s %5s %-12s %s" % ("shot", "lines", "span", "clip", "method", "scene"))
    for s in shots:
        print("%-8s %-9s %5.1f %4ds %-12s %s" % (s["id"], ",".join(s["lines"]), s["span"], s["flow_duration"], s["method"], s["scene"] or "-"))
    print("Waves: %d (chained shots must wait for their predecessor)" % (max(depth.values()) + 1))
    print("Credits: %s%s" % (total_credits, (" + %d clip(s) with unknown price (Veo) - run dry_run" % unknown) if unknown else ""))
    if cap and total_credits > cap:
        die("estimate %d > --max-credits %d. Use Omni 360p, fewer shots, or raise the cap." % (total_credits, cap), 2)
    print("Wrote SHOTS3D.json and flow_queue.json in " + P)


if __name__ == "__main__":
    main()
