#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""edit_clips.py - Flow video clips + voiceover  ->  master.mp4

* every clip is fitted to its voiceover span (speed-up/slow-down <=15 %, else trim / freeze last frame)
* audio sample 0 == video frame 0, output length == VO length (frame-quantised, no drift)
* dissolves between scenes, hard cuts inside chained shots (they are already continuous)
* karaoke captions (Hindi/English, libass), music bed with voice ducking, transition SFX, loudness norm
* Flow clip audio is dropped by default (Veo sometimes invents speech); --ambient-db -28 keeps it quietly
"""
import argparse, math, os, shutil, sys, tempfile
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *
import captions as C


def q(t, fps):                       # quantise a time to the frame grid
    return round(t * fps) / float(fps)


def amix_has_normalize():
    try:
        r = run(["ffmpeg", "-hide_banner", "-h", "filter=amix"])
        return "normalize" in r.stdout
    except Exception:
        return False


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--project", required=True)
    ap.add_argument("--out", default="master.mp4")
    ap.add_argument("--vo", help="voiceover file (default: VO.wav in the project)")
    ap.add_argument("--aspect", choices=["9:16", "16:9"])
    ap.add_argument("--res", type=int, help="short-side pixels: 1080 (default), 720, 540 (fast preview)")
    ap.add_argument("--fps", type=int, default=30)
    ap.add_argument("--xf", type=float, help="dissolve length (default: plan value)")
    ap.add_argument("--transition", default="fade", help="xfade name (fade, dissolve, smoothleft, wipeleft, circleopen...) or 'none'")
    ap.add_argument("--no-cut-on-chain", action="store_true", help="also dissolve between chained shots")
    ap.add_argument("--punch", action="store_true", help="subtle 6%% push-in on every shot")
    # captions
    ap.add_argument("--no-captions", action="store_true")
    ap.add_argument("--caption-mode", default="karaoke", choices=["karaoke", "pop", "box"])
    ap.add_argument("--caption-words", type=int, default=4)
    ap.add_argument("--lang", default="auto", choices=["auto", "hi", "en"])
    ap.add_argument("--font-file"); ap.add_argument("--font-name")
    ap.add_argument("--font-scale", type=float, default=1.0)
    ap.add_argument("--caption-margin", type=int, help="bottom margin px (default keeps clear of reels UI)")
    ap.add_argument("--upper", action="store_true")
    # audio
    ap.add_argument("--music"); ap.add_argument("--music-db", type=float, default=-22)
    ap.add_argument("--no-duck", action="store_true")
    ap.add_argument("--sfx-dir", help="folder with whoosh/transition sounds (played at every dissolve)")
    ap.add_argument("--sfx-db", type=float, default=-16)
    ap.add_argument("--ambient-db", type=float, help="keep the clips' own audio at this level (e.g. -28)")
    ap.add_argument("--vo-db", type=float, default=0)
    ap.add_argument("--no-loudnorm", action="store_true")
    # encode
    ap.add_argument("--crf", type=int, default=18); ap.add_argument("--preset", default="medium")
    ap.add_argument("--lowmem", action="store_true", help="phone/Termux: 720p, veryfast, 2 threads")
    ap.add_argument("--allow-missing", action="store_true", help="use grey placeholder for clips that are not generated yet")
    ap.add_argument("--keep-tmp", action="store_true")
    a = ap.parse_args()

    for b in ("ffmpeg", "ffprobe"):
        if not have(b):
            die(b + " not found. Install ffmpeg first (setup_mobile.sh / apt / brew).")
    P = os.path.abspath(a.project)
    plan = read_json(os.path.join(P, "SHOTS3D.json"))
    shots, meta = plan["shots"], plan["meta"]
    n = len(shots)
    fps = a.fps
    aspect = a.aspect or meta["aspect"]
    short = a.res or (720 if a.lowmem else 1080)
    if aspect == "9:16":
        W, H = short, int(round(short * 16 / 9 / 2.0)) * 2
    else:
        W, H = int(round(short * 16 / 9 / 2.0)) * 2, short
    preset, threads = ("veryfast", ["-threads", "2"]) if a.lowmem else (a.preset, [])

    vo = a.vo or first_existing(*[os.path.join(P, x) for x in ("VO.wav", "vo.wav", "voice.wav", "VO.mp3", "vo.mp3")])
    if not vo:
        die("voiceover not found (VO.wav). Run the studio's voice step or pass --vo.")
    T = q(probe(vo)["duration"], fps)
    if T <= 0:
        die("voiceover has zero length")

    # ---- timeline (frame quantised) ---------------------------------------------------------
    t0 = [0.0] + [q(s["t0"], fps) for s in shots[1:]]
    for i in range(1, n):
        t0[i] = min(max(t0[i], t0[i - 1] + 2.0 / fps), T - 2.0 / fps)
    t1 = t0[1:] + [T]
    D = [t1[i] - t0[i] for i in range(n)]
    xfs = []
    base_xf = a.xf if a.xf is not None else meta.get("xf", 0.3)
    for i in range(n - 1):
        if a.transition == "none":
            xfs.append(0.0)
        elif shots[i + 1]["method"] == "chain" and not a.no_cut_on_chain:
            xfs.append(0.0)
        else:
            xfs.append(q(min(base_xf, D[i] * 0.45, D[i + 1] * 0.45), fps))
    xfs.append(0.0)
    need = [D[i] + xfs[i] for i in range(n)]

    report = dict(output=a.out, size="%dx%d" % (W, H), fps=fps, voice_seconds=T, shots=[], warnings=[])
    tmp = tempfile.mkdtemp(prefix="v3d_")
    amb = a.ambient_db is not None

    # ---- 1) normalise every clip to an exact-length segment ---------------------------------
    segs = []
    for i, s in enumerate(shots):
        clip = os.path.join(P, s["clip"]) if s.get("clip") else None
        seg = os.path.join(tmp, "seg_%02d.mp4" % i)
        nd = need[i]
        frames = int(round(nd * fps))
        if not clip or not os.path.exists(clip):
            if not a.allow_missing:
                die("clip for %s is missing. Generate/ingest it (ingest_clips.py --status) or use --allow-missing." % s["id"])
            report["warnings"].append("%s: placeholder used" % s["id"])
            cmd = ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-f", "lavfi", "-i", "color=c=0x1c1c24:s=%dx%d:r=%d" % (W, H, fps)]
            if amb:
                cmd += ["-f", "lavfi", "-i", "anullsrc=r=48000:cl=stereo"]
            cmd += ["-t", "%.4f" % nd, "-pix_fmt", "yuv420p", "-c:v", "libx264", "-preset", "ultrafast", "-crf", "20"]
            cmd += (["-c:a", "aac", "-b:a", "128k", "-map", "0:v", "-map", "1:a"] if amb else ["-an"])
            cmd += [seg]
            run(cmd); segs.append(seg)
            report["shots"].append(dict(id=s["id"], mode="placeholder", span=round(D[i], 3)))
            continue
        info = probe(clip)
        c = info["duration"]
        f = c / nd
        if 1.0 < f <= 1.15:
            mode, ratio = "speed-up x%.2f" % f, f
        elif 0.85 <= f < 1.0:
            mode, ratio = "slow-down x%.2f" % f, f
        elif f > 1.15:
            mode, ratio = "trim (%.1fs cut off)" % (c - nd), 1.0
        else:
            mode, ratio = "freeze last frame (+%.1fs)" % (nd - c), 1.0
        if (info["height"] > info["width"]) != (H > W):
            report["warnings"].append("%s: clip orientation differs from project -> center crop" % s["id"])
        vf = []
        if ratio != 1.0:
            vf.append("setpts=PTS/%.6f" % ratio)
        vf += ["fps=%d" % fps, "scale=%d:%d:force_original_aspect_ratio=increase:flags=lanczos" % (W, H), "crop=%d:%d" % (W, H), "setsar=1"]
        if info["width"] and info["width"] * info["height"] < W * H * 0.8:
            vf.append("unsharp=5:5:0.35:5:5:0.0")
        vf += ["tpad=stop_mode=clone:stop_duration=5", "trim=end_frame=%d" % frames, "setpts=PTS-STARTPTS"]
        if a.punch:
            vf.append("zoompan=z='1+0.06*on/%d':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d=1:s=%dx%d:fps=%d" % (max(frames, 1), W, H, fps))
        vf.append("format=yuv420p")
        cmd = ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-i", clip]
        amap = None
        if amb:
            if info["has_audio"]:
                amap = "0:a:0"
            else:
                cmd += ["-f", "lavfi", "-t", "%.4f" % nd, "-i", "anullsrc=r=48000:cl=stereo"]
                amap = "1:a:0"
        cmd += ["-map", "0:v:0", "-vf", ",".join(vf)]
        if amb:
            af = []
            if ratio != 1.0 and info["has_audio"]:
                af.append("atempo=%.6f" % min(2.0, max(0.5, ratio)))
            af += ["aresample=48000", "aformat=channel_layouts=stereo", "apad", "atrim=duration=%.4f" % nd]
            cmd += ["-map", amap, "-af", ",".join(af), "-c:a", "aac", "-b:a", "160k"]
        else:
            cmd += ["-an"]
        cmd += ["-frames:v", str(frames), "-r", str(fps), "-c:v", "libx264", "-preset", "veryfast", "-crf", "14", "-pix_fmt", "yuv420p"] + threads + [seg]
        run(cmd)
        segs.append(seg)
        report["shots"].append(dict(id=s["id"], span=round(D[i], 3), clip_seconds=round(c, 2), mode=mode))
        print("  %s  %.2fs span  clip %.2fs  -> %s" % (s["id"], D[i], c, mode))

    # ---- 2) captions ------------------------------------------------------------------------
    ass_name = None
    fonts_dir = os.path.join(tmp, "fonts"); os.makedirs(fonts_dir, exist_ok=True)
    if not a.no_captions:
        words, exact = C.load_words(P, plan)
        if not words:
            report["warnings"].append("no caption words")
        else:
            if not exact:
                report["warnings"].append("captions use ESTIMATED timing (no WORDS.tsv)")
            lang = a.lang if a.lang != "auto" else C.detect_lang(words)
            fam, files = C.pick_font(lang, a.font_file, a.font_name)
            for fpath in files:
                shutil.copy(fpath, fonts_dir)
            if not files:
                report["warnings"].append("studio font not found, using system font '%s'" % fam)
            ass = C.build_ass(words, W, H, fam, a.caption_mode, a.caption_words, a.upper, a.font_scale, a.caption_margin)
            ass_name = "captions.ass"
            with open(os.path.join(tmp, ass_name), "w", encoding="utf-8") as fh:
                fh.write(ass)
            report["captions"] = dict(words=len(words), exact=exact, font=fam, lang=lang)

    # ---- 3) final graph ---------------------------------------------------------------------
    inputs, fc = [], []
    n_in = [0]

    def add_input(*pre, path):
        """append one input (optionally with options before -i) and return its index"""
        inputs.extend(list(pre) + ["-i", path])
        n_in[0] += 1
        return n_in[0] - 1

    for sg in segs:
        add_input(path=sg)
    vo_i = add_input(path=vo)
    mus_i = None
    if a.music:
        if not os.path.exists(a.music):
            die("music file not found: " + a.music)
        mus_i = add_input("-stream_loop", "-1", path=a.music)
    sfx_files = []
    if a.sfx_dir and os.path.isdir(a.sfx_dir):
        sfx_files = sorted(os.path.join(a.sfx_dir, x) for x in os.listdir(a.sfx_dir) if x.lower().endswith((".mp3", ".wav", ".ogg", ".m4a")))
    sfx_inputs = []
    for i in range(n - 1):
        if xfs[i] > 0 and sfx_files:
            idx = add_input(path=sfx_files[len(sfx_inputs) % len(sfx_files)])
            sfx_inputs.append((idx, t0[i + 1]))

    for i in range(n):
        fc.append("[%d:v]settb=AVTB,setpts=PTS-STARTPTS,fps=%d,format=yuv420p[v%d]" % (i, fps, i))
    cur = "v0"
    for i in range(1, n):
        out = "x%d" % i
        if xfs[i - 1] > 0:
            fc.append("[%s][v%d]xfade=transition=%s:duration=%.4f:offset=%.4f[%s]" % (cur, i, a.transition, xfs[i - 1], t0[i], out))
        else:
            fc.append("[%s][v%d]concat=n=2:v=1:a=0,settb=AVTB,fps=%d[%s]" % (cur, i, fps, out))
        cur = out
    if ass_name:
        fc.append("[%s]ass=%s:fontsdir=fonts[vout]" % (cur, ass_name))
    else:
        fc.append("[%s]null[vout]" % cur)

    mix = []
    duck = mus_i is not None and not a.no_duck
    fc.append("[%d:a]aresample=48000,aformat=channel_layouts=stereo,volume=%gdB,apad=whole_dur=%.4f,atrim=0:%.4f,asetpts=PTS-STARTPTS%s" % (
        vo_i, a.vo_db, T, T, ",asplit=2[vo_a][vo_sc]" if duck else "[vo_a]"))
    mix.append("[vo_a]")
    if mus_i is not None:
        fc.append("[%d:a]aresample=48000,aformat=channel_layouts=stereo,volume=%gdB,atrim=0:%.4f,asetpts=PTS-STARTPTS,afade=t=in:st=0:d=1.5,afade=t=out:st=%.3f:d=2.5[mus]" % (
            mus_i, a.music_db, T, max(0.0, T - 2.5)))
        if duck:
            fc.append("[mus][vo_sc]sidechaincompress=threshold=0.02:ratio=10:attack=15:release=350[musd]")
            mix.append("[musd]")
        else:
            mix.append("[mus]")
    for k, (idx, at) in enumerate(sfx_inputs):
        ms = max(0, int((at - 0.12) * 1000))
        fc.append("[%d:a]aresample=48000,aformat=channel_layouts=stereo,volume=%gdB,atrim=0:3,adelay=%d|%d[sfx%d]" % (idx, a.sfx_db, ms, ms, k))
        mix.append("[sfx%d]" % k)
    if amb:
        for i in range(n):
            fc.append("[%d:a]aresample=48000,aformat=channel_layouts=stereo,asetpts=PTS-STARTPTS[a%d]" % (i, i))
        acur = "a0"
        for i in range(1, n):
            out = "ax%d" % i
            if xfs[i - 1] > 0:
                fc.append("[%s][a%d]acrossfade=d=%.4f:c1=tri:c2=tri[%s]" % (acur, i, xfs[i - 1], out))
            else:
                fc.append("[%s][a%d]concat=n=2:v=0:a=1[%s]" % (acur, i, out))
            acur = out
        fc.append("[%s]volume=%gdB,apad=whole_dur=%.4f,atrim=0:%.4f[amb]" % (acur, a.ambient_db, T, T))
        mix.append("[amb]")
    k = len(mix)
    if amix_has_normalize():
        fc.append("%samix=inputs=%d:duration=longest:dropout_transition=0:normalize=0[mx]" % ("".join(mix), k))
    else:
        fc.append("%samix=inputs=%d:duration=longest:dropout_transition=0,volume=%d[mx]" % ("".join(mix), k, k))
    tail = "aresample=48000" if a.no_loudnorm else "loudnorm=I=-14:TP=-1.5:LRA=11,aresample=48000"
    fc.append("[mx]%s,alimiter=limit=0.95,atrim=0:%.4f[aout]" % (tail, T))

    gpath = os.path.join(tmp, "graph.txt")
    with open(gpath, "w", encoding="utf-8") as fh:
        fh.write(";\n".join(fc))
    out_path = a.out if os.path.isabs(a.out) else os.path.join(P, a.out)
    cmd = ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error"] + inputs + [
        "-filter_complex_script", gpath, "-map", "[vout]", "-map", "[aout]",
        "-c:v", "libx264", "-preset", preset, "-crf", str(a.crf), "-pix_fmt", "yuv420p", "-r", str(fps),
        "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", "-t", "%.4f" % T] + threads + [out_path]
    print("  assembling %d shots + audio ..." % n)
    run(cmd, cwd=tmp)

    fin = probe(out_path)
    report["final_seconds"] = round(fin["duration"], 3)
    report["final_size"] = "%dx%d" % (fin["width"], fin["height"])
    if abs(fin["duration"] - T) > 0.15:
        report["warnings"].append("final length %.2fs differs from voice %.2fs" % (fin["duration"], T))
    write_json(os.path.join(P, "edit_report.json"), report)
    if not a.keep_tmp:
        shutil.rmtree(tmp, ignore_errors=True)
    else:
        print("  temp kept:", tmp)
    print("DONE  %s  %s  %.2fs (voice %.2fs)" % (out_path, report["final_size"], fin["duration"], T))
    for w in report["warnings"]:
        warn(w)


if __name__ == "__main__":
    try:
        main()
    except RuntimeError as e:
        die(str(e))
