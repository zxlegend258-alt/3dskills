# -*- coding: utf-8 -*-
"""captions.py - WORDS.tsv (or estimated line timings) -> karaoke .ass subtitles (Hindi/English safe)."""
import os, re
from common import *

PUNCT_END = re.compile(r"[.!?।,;:—–-]$")
DEVA = re.compile(r"[\u0900-\u097F]")

def load_words(P, plan):
    """-> list of (start, end, word). Exact when WORDS.tsv exists, else spread per line (approximate)."""
    wp = os.path.join(P, "WORDS.tsv")
    out = []
    if os.path.exists(wp):
        for r in read_tsv(wp):
            try:
                out.append((max(0.0, float(r["start"])), float(r["end"]), r["word"]))
            except (KeyError, ValueError):
                pass
        out.sort(key=lambda x: x[0])
        if out:
            return out, True
    for ln in plan.get("line_table", []):
        ws = ln["text"].split()
        if not ws:
            continue
        wts = [max(1, len(w)) for w in ws]
        tot, t = float(sum(wts)), ln["t0"]
        span = max(0.3, ln["t1"] - ln["t0"])
        for w, wt in zip(ws, wts):
            d = span * wt / tot
            out.append((t, t + d, w)); t += d
    return out, False

def detect_lang(words):
    return "hi" if any(DEVA.search(w) for _, _, w in words[:200]) else "en"

def pick_font(lang, font_file=None, font_name=None, fonts_dir=None):
    """-> (family_name, [font files to copy into the libass fonts dir])"""
    root = studio_root()
    cands = []
    if font_file:
        cands.append(font_file)
    if root:
        if lang == "hi":
            cands += [os.path.join(root, "fonts/hindi", n) for n in ("Baloo2-ExtraBold.ttf", "Khand-Bold.ttf", "Baloo2-Bold.ttf")]
        else:
            cands += [os.path.join(root, "fonts/english", n) for n in ("Anton-Regular.ttf", "Montserrat-Bold.ttf", "LiberationSans-Bold.ttf")]
    f = first_existing(*cands)
    if f:
        fam = font_name
        if not fam:
            try:
                from PIL import ImageFont
                fam = ImageFont.truetype(f, 40).getname()[0]
                sty = ImageFont.truetype(f, 40).getname()[1]
                if sty and sty.lower() not in ("regular", "bold", "italic", "bold italic", "normal"):
                    fam = "%s %s" % (fam, sty)  # e.g. 'Baloo 2 ExtraBold'
            except Exception:
                fam = os.path.splitext(os.path.basename(f))[0]
        return fam, [f]
    return (font_name or ("Noto Sans Devanagari" if lang == "hi" else "DejaVu Sans")), []

def _t(sec):
    sec = max(0.0, sec)
    cs = int(round(sec * 100))
    h, cs = divmod(cs, 360000); m, cs = divmod(cs, 6000); s, cs = divmod(cs, 100)
    return "%d:%02d:%02d.%02d" % (h, m, s, cs)

def chunk(words, max_words=4, max_chars=30, gap=0.45):
    chunks, cur = [], []
    for i, w in enumerate(words):
        cur.append(w)
        nxt = words[i + 1] if i + 1 < len(words) else None
        chars = sum(len(x[2]) + 1 for x in cur)
        if (len(cur) >= max_words or chars >= max_chars or PUNCT_END.search(w[2]) or nxt is None
                or nxt[0] - w[1] > gap):
            chunks.append(cur); cur = []
    return chunks

def build_ass(words, W, H, family, mode="karaoke", max_words=4, upper=False, font_scale=1.0, margin_v=None):
    portrait = H > W
    size = int((W * 0.078 if portrait else H * 0.078) * font_scale)
    mv = margin_v if margin_v is not None else (int(H * 0.17) if portrait else int(H * 0.08))
    maxc = 24 if portrait else 40
    hl, base, outline = "&H0000E5FF", "&H00FFFFFF", "&H00000000"   # yellow / white / black  (BGR)
    border = 1
    if mode == "box":
        border, outline = 3, "&H99000000"
    head = ("[Script Info]\nScriptType: v4.00+\nPlayResX: %d\nPlayResY: %d\nWrapStyle: 0\nScaledBorderAndShadow: yes\n\n"
            "[V4+ Styles]\nFormat: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, "
            "Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\n"
            "Style: Cap,%s,%d,%s,%s,%s,&H80000000,-1,0,0,0,100,100,0,0,%d,%d,2,2,%d,%d,%d,1\n\n"
            "[Events]\nFormat: Layer, Start, End, Style, Name, Effect, Text\n"
            % (W, H, family, size, hl if mode == "karaoke" else base, base, outline, border,
               max(4, size // 12), int(W * 0.07), int(W * 0.07), mv))
    ev = []
    chunks = chunk(words, max_words=max_words, max_chars=maxc)
    for ci, ch in enumerate(chunks):
        st = ch[0][0]
        en = ch[-1][1] + 0.06
        if ci + 1 < len(chunks):
            en = min(en, chunks[ci + 1][0][0])
        en = max(en, st + 0.25)
        if mode == "karaoke":
            parts = []
            for i, (s, e, w) in enumerate(ch):
                nxt = ch[i + 1][0] if i + 1 < len(ch) else e
                parts.append("{\\kf%d}%s" % (max(1, int(round((nxt - s) * 100))), w.upper() if upper else w))
            text = " ".join(parts)
        else:
            text = " ".join(w.upper() if upper else w for _, _, w in ch)
            if mode == "pop":
                text = "{\\fad(50,40)\\fscx88\\fscy88\\t(0,110,\\fscx100\\fscy100)}" + text
        ev.append("Dialogue: 0,%s,%s,Cap,,,%s" % (_t(st), _t(en), text))
    return head + "\n".join(ev) + "\n"
