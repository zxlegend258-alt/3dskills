#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""selftest.py - end-to-end check with synthetic clips/voice (no Flow, no credits, ~1 min).
   python selftest.py [--keep]    -> prints PASS/FAIL per stage"""
import argparse, json, os, shutil, subprocess, sys, tempfile
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from common import *

LINES = [
    ("01", "एक छोटी सी बिल्ली मोची शहर में रहती थी।", "mochi peeks out of a cardboard box on a rainy street", "rain"),
    ("02", "उसे हमेशा नई जगहें देखना पसंद था।", "mochi hops onto a puddle and looks up curiously", "rain"),
    ("03", "एक दिन उसने एक पुराना नक्शा पाया।", "mochi finds a glowing treasure map under a bench", "park"),
    ("04", "नक्शे ने उसे जंगल की तरफ बुलाया।", "mochi runs along a forest path, leaves swirling", "forest"),
    ("05", "और असली कहानी वहीं से शुरू हुई।", "mochi stops at a huge glowing tree and smiles", "forest"),
]

def sh(cmd):
    r = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if r.returncode:
        raise RuntimeError("%s\n%s" % (" ".join(cmd)[:200], r.stderr[-1500:]))
    return r.stdout

def check(name, ok, extra=""):
    print("%-4s %s %s" % ("PASS" if ok else "FAIL", name, extra))
    return ok

def make_project(P, aspect):
    os.makedirs(P, exist_ok=True)
    with open(os.path.join(P, "LINES.tsv"), "w", encoding="utf-8") as f:
        f.write("id\ttext\tgap\tscene\taction\n")
        for i, t, act, sc in LINES:
            f.write("%s\t%s\t0.4\t%s\t%s\n" % (i, t, sc, act))
    cur, rows = 0.2, ["line\ti\tstart\tend\tword\tsrc"]
    for i, t, _, _ in LINES:
        for k, w in enumerate(t.split()):
            rows.append("%s\t%d\t%.2f\t%.2f\t%s\tcartesia" % (i, k, cur, cur + 0.38, w)); cur += 0.42
        cur += 0.4
    open(os.path.join(P, "WORDS.tsv"), "w", encoding="utf-8").write("\r\n".join(rows) + "\r\n")
    T = cur + 0.3
    sh(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", "sine=frequency=180:duration=%.2f" % T,
        "-af", "volume=0.25,tremolo=f=4:d=0.9", "-ar", "44100", os.path.join(P, "VO.wav")])
    return T

def fake_clip(path, aspect, dur, color):
    size = "720x1280" if aspect == "9:16" else "1280x720"
    sh(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", "testsrc2=s=%s:r=24:d=%d" % (size, dur),
        "-f", "lavfi", "-i", "sine=frequency=%d:duration=%d" % (300 + color * 40, dur),
        "-vf", "hue=h=%d" % (color * 50), "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", "-shortest", path])

def scenario(root, aspect, model, extra_edit, label, plan_extra=()):
    P = os.path.join(root, label)
    T = make_project(P, aspect)
    ok = True
    sh([sys.executable, os.path.join(HERE, "plan_shots.py"), "--project", P, "--aspect", aspect, "--model", model,
        "--character", "Mochi=a small round orange cat with big green eyes and a blue scarf", "--style", "pixar"] + list(plan_extra))
    plan = read_json(os.path.join(P, "SHOTS3D.json"))
    q = read_json(os.path.join(P, "flow_queue.json"))
    ok &= check(label + ": plan has shots", len(plan["shots"]) >= 3, "(%d shots)" % len(plan["shots"]))
    ok &= check(label + ": shots <= model max", all(s["span"] <= (10 if "Omni" in model else 8) for s in plan["shots"]))
    ok &= check(label + ": timeline covers VO", abs(plan["shots"][-1]["t1"] - T) < 0.5 and plan["shots"][0]["t0"] == 0.0)
    ok &= check(label + ": queue has video call", any(c["tool"].startswith("flow_") for st in q["steps"] for c in st["calls"]))
    if plan_extra:
        ok &= check(label + ": chain used for same scene", any(s["method"] == "chain" for s in plan["shots"]))
    args = []
    for i, s in enumerate(plan["shots"]):
        cp = os.path.join(P, "raw_%s.mp4" % s["id"])
        fake_clip(cp, aspect, s["flow_duration"], i)
        args += ["--clip", "%s=%s" % (s["id"], cp), "--media-id", "%s=fake%d" % (s["id"], i)]
    sh([sys.executable, os.path.join(HERE, "ingest_clips.py"), "--project", P] + args)
    music = os.path.join(root, "music.wav")
    if not os.path.exists(music):
        sh(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", "sine=frequency=440:duration=30", music])
    sfxd = os.path.join(root, "sfx"); os.makedirs(sfxd, exist_ok=True)
    if not os.listdir(sfxd):
        sh(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", "anoisesrc=d=1:c=pink", os.path.join(sfxd, "w.wav")])
    out = sh([sys.executable, os.path.join(HERE, "edit_clips.py"), "--project", P, "--music", music, "--sfx-dir", sfxd] + extra_edit)
    info = probe(os.path.join(P, "master.mp4"))
    ok &= check(label + ": master.mp4 length == voice", abs(info["duration"] - T) < 0.12, "(%.2f vs %.2f)" % (info["duration"], T))
    ok &= check(label + ": has audio+video", info["has_video"] and info["has_audio"])
    exp = (1080, 1920) if aspect == "9:16" else (1920, 1080)
    if "--res" in extra_edit:
        exp = (probe(os.path.join(P, "master.mp4"))["width"], probe(os.path.join(P, "master.mp4"))["height"])
    ok &= check(label + ": size", (info["width"], info["height"]) == exp, "(%dx%d)" % (info["width"], info["height"]))
    rep = read_json(os.path.join(P, "edit_report.json"))
    ok &= check(label + ": captions built", rep.get("captions", {}).get("exact") is True, str(rep.get("captions")))
    return ok, P

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--keep", action="store_true"); a = ap.parse_args()
    root = tempfile.mkdtemp(prefix="v3d_selftest_")
    allok = True
    try:
        o, P1 = scenario(root, "9:16", "omni", ["--res", "720", "--punch", "--ambient-db", "-28"], "reel_omni", ["--max-lines", "1"])
        allok &= o
        o, P2 = scenario(root, "16:9", "veo-fast", ["--res", "540", "--lowmem", "--transition", "smoothleft"], "wide_veo")
        allok &= o
    except Exception as e:
        print("FAIL exception:", e); allok = False
    print("\nSELFTEST " + ("PASSED" if allok else "FAILED"), "(files in %s)" % root if a.keep or not allok else "")
    if not (a.keep or not allok):
        shutil.rmtree(root, ignore_errors=True)
    sys.exit(0 if allok else 1)

if __name__ == "__main__":
    main()
